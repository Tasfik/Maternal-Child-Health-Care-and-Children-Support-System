var a=0;

function test(a){
  console.log(a);
}

for(i=0;i<5;i++){
  if(i%2==0)
  console.log("Tasfik Rahman")
}

test("Ishak");
